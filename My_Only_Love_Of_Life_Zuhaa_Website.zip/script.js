(() => {
  const canvas = document.getElementById("stars");
  const ctx = canvas.getContext("2d");
  const headline = document.getElementById("headline");
  const replay = document.getElementById("replay");
  let width = 0, height = 0, dpr = 1, particles = [], textPoints = [];
  let frame = 0;
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    canvas.style.width = width + "px";
    canvas.style.height = height + "px";
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    makeStars();
    makeTextPoints();
  }

  function makeStars() {
    const count = Math.min(360, Math.floor(width * height / 3600));
    particles = Array.from({ length: count }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      r: Math.random() * 1.25 + .25,
      alpha: Math.random() * .7 + .15,
      twinkle: Math.random() * .018 + .003,
      drift: (Math.random() - .5) * .13,
      fall: Math.random() * .22 + .025
    }));
  }

  function makeTextPoints() {
    const off = document.createElement("canvas");
    const octx = off.getContext("2d");
    const isMobile = width < 620;
    const text = isMobile ? "MY ONLY LOVE" : "MY ONLY LOVE OF LIFE (ZUHAA)";
    const fontSize = Math.min(isMobile ? width / 12.5 : width / 25, isMobile ? 42 : 54);
    off.width = Math.floor(width * dpr);
    off.height = Math.floor(height * dpr);
    octx.scale(dpr, dpr);
    octx.fillStyle = "#fff";
    octx.textAlign = "center";
    octx.textBaseline = "middle";
    octx.font = `500 ${fontSize}px Georgia, "Times New Roman", serif`;
    let fitted = text;
    while (octx.measureText(fitted).width > width * .9 && fontSize > 12) {
      break;
    }
    octx.fillText(fitted, width / 2, height / 2, width * .91);
    const data = octx.getImageData(0, 0, off.width, off.height).data;
    textPoints = [];
    const step = width < 620 ? 5 : 4;
    for (let y = 0; y < off.height; y += step) {
      for (let x = 0; x < off.width; x += step) {
        if (data[(y * off.width + x) * 4 + 3] > 120 && Math.random() > .12) {
          textPoints.push({ x: x / dpr, y: y / dpr });
        }
      }
    }
    // Particle destinations are sampled from the letters themselves.
    textPoints = textPoints.sort(() => Math.random() - .5).slice(0, 2400);
  }

  function draw() {
    frame++;
    ctx.clearRect(0, 0, width, height);
    for (const p of particles) {
      p.alpha += (Math.random() - .5) * p.twinkle;
      p.alpha = Math.max(.12, Math.min(.95, p.alpha));
      p.x += p.drift;
      p.y += p.fall;
      if (p.y > height + 2) { p.y = -2; p.x = Math.random() * width; }
      if (p.x < -2) p.x = width + 2;
      if (p.x > width + 2) p.x = -2;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(239,232,255,${p.alpha})`;
      ctx.fill();
    }

    // A few brighter, slowly drifting flecks give the text a star-dust feel.
    const total = textPoints.length;
    for (let i = 0; i < total; i++) {
      const pt = textPoints[i];
      const shimmer = .52 + .48 * Math.sin(frame * .025 + i * .13);
      ctx.beginPath();
      ctx.arc(pt.x + Math.sin(frame * .006 + i) * .25, pt.y, (i % 5 === 0 ? 1.15 : .72), 0, Math.PI * 2);
      ctx.fillStyle = `rgba(246,239,255,${.35 + shimmer * .62})`;
      ctx.fill();
    }
    if (!reducedMotion) requestAnimationFrame(draw);
  }

  function replayAnimation() {
    // Briefly fade the particle text, then restore it with a gentle shimmer.
    headline.style.opacity = "0";
    textPoints = [];
    setTimeout(() => {
      makeTextPoints();
      headline.style.opacity = "1";
    }, 350);
  }

  replay.addEventListener("click", replayAnimation);
  window.addEventListener("resize", resize);
  resize();
  draw();
})();
